package com.example.combomod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

public class ComboModClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("combomod", "combo"));
    private static KeyBinding comboKey;

    @Override
    public void onInitializeClient() {
        comboKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combomod.fq",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G, // rebind in-game under Controls > Combo Mod
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (comboKey.wasPressed()) {
                if (client.player == null) continue;

                // F equivalent — swap item to offhand
                client.player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                        PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                        BlockPos.ORIGIN,
                        Direction.DOWN
                ));

                // Q equivalent — drop item
                if (!client.player.isSpectator()) {
                    client.player.dropSelectedItem(false); // true = ctrl+Q, drops full stack
                }
            }
        });
    }
}
