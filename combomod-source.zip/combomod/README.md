# Combo Mod

Client-side Fabric mod for Minecraft 1.21.11. Holds a single keybind
(default: **G**, rebind it in Controls) that sends the swap-offhand
and drop-item actions in the same client tick.

## Why you're building this yourself

Compiling a Fabric mod requires Gradle to download Minecraft, Yarn
mappings, and Fabric Loader/API from Mojang's and Fabric's servers.
That has to happen on a machine with internet access — it can't be
done in a sandboxed environment with no network access. This project
is fully written and ready to go; you just need to build it.

## Build instructions

1. Install **JDK 21** (Temurin/Adoptium works well).
2. Open a terminal in this folder.
3. Run:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`
4. First build will take a few minutes (downloading Minecraft/mappings).
5. Your jar will be at `build/libs/combomod-1.0.0.jar`.
6. Drop it into your `.minecraft/mods` folder (with Fabric Loader +
   Fabric API installed for 1.21.11).

## Before you build

Double check `gradle.properties` — the `yarn_mappings`, `loader_version`,
and `fabric_version` values are current as of my knowledge, but Fabric
updates these often. Get the exact current numbers for 1.21.11 from
https://fabricmc.net/develop/ before building, and paste them in.

## Note on Gradle wrapper files

This bundle doesn't include the `gradle/wrapper/gradle-wrapper.jar`
binary (binary files can't be generated here). Run `gradle wrapper`
once with any local Gradle install to generate it, or just open the
project in IntelliJ IDEA with the Fabric/Gradle plugins — it'll set
that up automatically when you import the project.
