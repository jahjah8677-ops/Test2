# Easy Villager Breeder

A Fabric mod for Minecraft 1.21.11 that makes villager breeding fast and
easy. Vanilla villager breeding requires each villager to be "willing"
(carrying 3 bread, or 12 carrots/potatoes/beetroot) AND requires more
free beds than villagers in the village. This mod keeps the food
requirement but makes it much lighter, and drops the bed/population
check entirely.

## What it does

Every few ticks, it scans each loaded world for adult villagers. Any two
adult villagers within 4 blocks of each other will breed automatically
IF both are carrying at least one piece of breeding food (bread, carrot,
potato, or beetroot) — just one item, not vanilla's 3 bread / 12 crops.
Breeding consumes one food item from each parent. Each villager has its
own short cooldown (5 seconds by default) before it can breed again.

To "give" a villager food, throw it near them (Q to drop) — villagers
already pick up dropped food automatically, that's vanilla behavior this
mod doesn't change.

## This works in singleplayer automatically

Like the reach mod, this runs on the "logical server" (the integrated
server built into singleplayer), so it just works the moment you load a
world. For multiplayer, the server itself needs this mod installed.

## Adjusting the behavior

In `src/main/java/com/example/villagerbreeder/VillagerBreederMod.java`:

```java
private static final double BREED_RADIUS = 4.0;        // how close villagers must be
private static final int BREED_COOLDOWN_TICKS = 100;    // 20 ticks = 1 second
private static final int SCAN_INTERVAL_TICKS = 10;      // how often it checks
```

Lower the cooldown for even faster breeding, or raise it if you want more
control (e.g. to avoid quickly overcrowding a village).

## A heads-up

There's still no population/bed cap check, so if you keep villagers fed
and packed close together, numbers can grow quickly. Requiring food
slows this down naturally (you have to keep supplying it), but if it's
still too fast for your taste, raise `BREED_COOLDOWN_TICKS`.

## Build instructions

Same proven setup as the other mods:

1. Create/reuse a GitHub repo
2. Delete any placeholder `blank.yml` workflow if present
3. Upload this `villagerbreeder-source.zip` to the repo root
4. Add `.github/workflows/build.yml` (included in this zip) to the repo
5. Commit — it'll build automatically; grab the jar from the Actions
   run's Artifacts section

Or locally: unzip, install JDK 21, run `./gradlew build`, jar appears in
`build/libs/`.

## Installing

Install Fabric Loader + Fabric API for 1.21.11, drop this jar into
`.minecraft/mods`, launch. No keybind or menu — it's active automatically
once you're in a world.
