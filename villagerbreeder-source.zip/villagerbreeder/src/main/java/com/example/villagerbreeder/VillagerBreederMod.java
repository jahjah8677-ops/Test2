package com.example.villagerbreeder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class VillagerBreederMod implements ModInitializer {

    // How close two villagers need to be to breed, in blocks.
    private static final double BREED_RADIUS = 4.0;
    // Cooldown per villager between breeding attempts, in ticks (20 ticks = 1 second).
    // Vanilla's effective cycle (gathering food, waiting for willingness) is usually
    // several minutes; this makes it a flat, short timer instead, but food is still required.
    private static final int BREED_COOLDOWN_TICKS = 100; // 5 seconds

    // Only actually scan for pairs every few ticks to keep this cheap.
    private static final int SCAN_INTERVAL_TICKS = 10;

    private static final Map<UUID, Integer> lastBredTick = new HashMap<>();
    private int tickCounter = 0;

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
    }

    private void onServerTick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter % SCAN_INTERVAL_TICKS != 0) {
            return;
        }

        for (ServerWorld world : server.getWorlds()) {
            Box wholeLoadedArea = new Box(
                    -30000000, world.getBottomY(), -30000000,
                    30000000, world.getTopY() + 1, 30000000
            );

            List<VillagerEntity> villagers = world.getEntitiesByType(
                    TypeFilter.instanceOf(VillagerEntity.class),
                    wholeLoadedArea,
                    v -> !v.isBaby()
            );

            for (int i = 0; i < villagers.size(); i++) {
                VillagerEntity a = villagers.get(i);
                if (isOnCooldown(a) || !hasFood(a)) {
                    continue;
                }

                for (int j = i + 1; j < villagers.size(); j++) {
                    VillagerEntity b = villagers.get(j);
                    if (isOnCooldown(b) || !hasFood(b)) {
                        continue;
                    }

                    if (a.distanceTo(b) <= BREED_RADIUS) {
                        breed(world, a, b);
                        break; // 'a' just bred, move on to the next villager
                    }
                }
            }
        }
    }

    private boolean isOnCooldown(VillagerEntity villager) {
        Integer last = lastBredTick.get(villager.getUuid());
        return last != null && (tickCounter - last) < BREED_COOLDOWN_TICKS;
    }

    // A villager just needs to be CARRYING at least one piece of breeding food
    // (bread, carrot, potato, or beetroot) - much less than vanilla's 3 bread /
    // 12 crops requirement. Villagers pick up dropped food automatically, so
    // throwing food near them (vanilla behavior) is how you "give" it to them.
    private boolean hasFood(VillagerEntity villager) {
        SimpleInventory inventory = villager.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            if (isBreedingFood(inventory.getStack(i))) {
                return true;
            }
        }
        return false;
    }

    private boolean isBreedingFood(ItemStack stack) {
        return !stack.isEmpty() && (
                stack.isOf(Items.BREAD)
                        || stack.isOf(Items.CARROT)
                        || stack.isOf(Items.POTATO)
                        || stack.isOf(Items.BEETROOT)
        );
    }

    private void consumeFood(VillagerEntity villager) {
        SimpleInventory inventory = villager.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (isBreedingFood(stack)) {
                stack.decrement(1);
                inventory.setStack(i, stack);
                return;
            }
        }
    }

    private void breed(ServerWorld world, VillagerEntity a, VillagerEntity b) {
        PassiveEntity childRaw = a.createChild(world, b);
        if (!(childRaw instanceof VillagerEntity child)) {
            return;
        }

        consumeFood(a);
        consumeFood(b);

        double x = (a.getX() + b.getX()) / 2.0;
        double y = (a.getY() + b.getY()) / 2.0;
        double z = (a.getZ() + b.getZ()) / 2.0;

        child.refreshPositionAndAngles(BlockPos.ofFloored(x, y, z), 0.0F, 0.0F);
        child.setBreedingAge(-24000); // spawn as a baby; grows up over time like normal
        world.spawnEntity(child);

        lastBredTick.put(a.getUuid(), tickCounter);
        lastBredTick.put(b.getUuid(), tickCounter);
    }
}

