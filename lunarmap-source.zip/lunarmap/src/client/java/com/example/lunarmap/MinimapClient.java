package com.example.lunarmap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

public class MinimapClient implements ClientModInitializer {

    // On-screen size of the minimap square, in pixels.
    private static final int MAP_SIZE = 128;
    // How many screen pixels represent one in-world block. 2 = zoomed in, 1 = zoomed out further.
    private static final int PIXELS_PER_BLOCK = 2;
    // How many blocks out from the player we sample in each direction.
    private static final int RADIUS = (MAP_SIZE / PIXELS_PER_BLOCK) / 2;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(Identifier.of("lunarmap", "minimap"), this::render);
    }

    private void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden) {
            return;
        }

        ClientWorld world = client.world;
        BlockPos playerPos = client.player.getBlockPos();

        int screenX = context.getScaledWindowWidth() - MAP_SIZE - 10;
        int screenY = 10;

        // Background panel behind the terrain.
        context.fill(screenX - 2, screenY - 2, screenX + MAP_SIZE + 2, screenY + MAP_SIZE + 2, 0x88000000);

        BlockPos.Mutable samplePos = new BlockPos.Mutable();

        for (int dz = -RADIUS; dz < RADIUS; dz++) {
            int worldZ = playerPos.getZ() + dz;
            for (int dx = -RADIUS; dx < RADIUS; dx++) {
                int worldX = playerPos.getX() + dx;

                int topY = world.getTopY(Heightmap.Type.WORLD_SURFACE, worldX, worldZ) - 1;
                samplePos.set(worldX, topY, worldZ);

                BlockState state = world.getBlockState(samplePos);
                MapColor mapColor = state.getMapColor(world, samplePos);

                int argb = 0xFF000000 | (mapColor.color & 0xFFFFFF);

                int pixelX = screenX + (dx + RADIUS) * PIXELS_PER_BLOCK;
                int pixelY = screenY + (dz + RADIUS) * PIXELS_PER_BLOCK;

                context.fill(pixelX, pixelY, pixelX + PIXELS_PER_BLOCK, pixelY + PIXELS_PER_BLOCK, argb);
            }
        }

        // Player marker: a small red square at the center (map is always player-centered).
        int centerX = screenX + MAP_SIZE / 2;
        int centerY = screenY + MAP_SIZE / 2;
        context.fill(centerX - 2, centerY - 2, centerX + 2, centerY + 2, 0xFFFF3B3B);

        // North indicator above the map (map is north-up / not rotated with player facing).
        context.drawTextWithShadow(client.textRenderer, "N", screenX + MAP_SIZE / 2 - 3, screenY - 11, 0xFFFFFF);
    }
}
