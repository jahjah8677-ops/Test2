# Simple Minimap

A Fabric mod for Minecraft 1.21.11 that renders a small, always-on
top-down terrain minimap in the top-right corner of your screen —
the core idea behind Lunar Client's world map, built from scratch.

## What it does

- Shows a 128x128 pixel minimap of the terrain around you, sampled
  from actual block map colors (the same colors vanilla in-hand maps use)
- A red dot marking your position (map is always centered on you)
- A north indicator so you know which way you're facing on the map
- Updates live, every frame, automatically — no keybind needed

## What it does NOT do (yet)

This is a solid MVP, not a full Lunar Client clone. It doesn't include:
- Waypoints / custom markers
- A rotating map that turns with your facing direction (this one is
  always north-up)
- A fullscreen/zoomed-out map view
- Player/mob blips for other entities
- Caching — it resamples every block every frame, which is fine for a
  128x128 map at 2px/block (4096 samples) but could be optimized further
  if you want a bigger map or better performance on weaker hardware

Happy to add any of these if you want — the waypoint system and a
rotating map are the two most requested Lunar-style features and are
both reasonable next additions.

## Adjusting the map

In `src/client/java/com/example/lunarmap/MinimapClient.java`:

```java
private static final int MAP_SIZE = 128;        // on-screen size in pixels
private static final int PIXELS_PER_BLOCK = 2;   // zoom (2 = each block is a 2x2 pixel square)
```

Increase `MAP_SIZE` for a bigger map, or `PIXELS_PER_BLOCK` for more zoom
(fewer, larger blocks shown) vs. less zoom (more blocks, smaller pixels).

## Build instructions

Same proven setup as the other mods — this one uses the exact same
Loom/Yarn/Fabric API versions already confirmed working:

1. Create/reuse a GitHub repo
2. Delete any placeholder `blank.yml` workflow if present
3. Upload this `lunarmap-source.zip` to the repo root
4. Add `.github/workflows/build.yml` (included in this zip) to the repo
5. Commit — it'll build automatically; grab the jar from the Actions
   run's Artifacts section

Or locally: unzip, install JDK 21, run `./gradlew build`, jar appears in
`build/libs/`.

## Installing and using it

Same as the reach mod: install Fabric Loader + Fabric API for 1.21.11,
drop this jar into `.minecraft/mods`, launch. The minimap appears
automatically in the corner once you're in a world — no menu, no keybind.
